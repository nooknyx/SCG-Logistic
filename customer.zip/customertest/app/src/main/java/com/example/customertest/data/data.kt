package com.example.customertest.data

data class data(var name: String ?=null, var url: String ?=null)
{

}
